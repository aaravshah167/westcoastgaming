from wikipedia import exceptions
import smtplib
import os
import pyttsx3
import datetime
import wikipedia
import webbrowser
import speech_recognition as sr

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)
def speak(audio):
    engine.say(audio)
    engine.runAndWait()
def wishME():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good Morning!")

    elif hour>=12 and hour<18:
        speak("Good Afternoon")
    else:
        speak("Good Evening")
    speak("I am your friendly AI Desktop Assistant! How can I help you?")

def takeCommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')
        print(f"User said: {query}\n")
    
    except exceptions as e:
        print(e)
        print("Say that again please...")
        return "None"
    return query

def sendEmail(to, content):
    server = smtplib.SMTP('smtp.outlook.com', 'a2r1a1v1')
    server.ehlo()
    server.starttls()
    server.login('aaravshah167@outlook.com', 'a2r1a1v1')
    server.sendmail('aaravshah167@outlook.com', to, content)
    server.close()

if __name__ == "__main__":
    wishME()
    while True:
        query = takeCommand().lower()
        if 'wikipedia' in query:
            speak('Searching Wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak("According to Wikipedia")
            speak(results)
            print(results)

        elif 'open youtube' in query:
            webbrowser.open("youtube.com")
        elif 'open google' in query:
            webbrowser.open("google.com")
        elif 'play music' in query:
            webbrowser.open("https://music.youtube.com/watch?v=qFkNATtc3mc&feature=share")
        elif 'the time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")
            speak(f"The time is {strTime}")
        elif 'open vs code' in query:
            codePath = "C:\\Users\\vivek shah\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
            os.startfile(codePath)
        elif 'email to mom' in query:
            try:
                speak("What should I say?")
                content = takeCommand()
                to = "nehabadanishah@gmail.com"
                sendEmail(to, content)
                speak("Email has been sent")
            except exceptions as e:
                print(e)
                speak("An Error accured and the email was not sent")
        elif 'you are annoying' in query:
            speak("Sorry, I will try to improve it.")
        elif 'answer my question' in query:
            speak("Ok, Please ask your Question")
        elif 'can you get smarter' in query:
            speak("I'm certainly trying.")
        elif 'how are you' in query:
            speak("I am fine! How may I help you?")
        elif 'tell me a joke' in query:
            speak("Why is maths book so sad? Because it has so many problems!")
        elif 'you are beautiful' in query:
            speak("Thank you!")
        elif 'can you help me' in query:
            speak("Yes, tell me your problem.")
        elif 'you are so clever' in query:
            speak("Thank You!")
        elif 'who is the owner of google' in query:
            speak("Sergey Brin and Larry Page are the founders of Google")
        elif 'who is the owner of microsoft' in query:
            speak("Bill Gates is the owner and founder of Microsoft.")
        elif 'who is the ceo of google' in query:
            speak("Sundar Pichai is the CEO of google")
        elif 'who is the ceo of microsoft' in query:
            speak("Satya Nadella is the CEO of Microsoft.")
        elif 'I am very angry right now' in query:
            speak("Go for jogging, then you will feel better")
        elif 'Are you busy' in query:
            speak("I am busy talking with you!")
        elif 'can you help me' in query:
            speak("Yes, tell me your problem.")
        elif 'you are so clever' in query:
            speak("Thanks! Anything else you want.")
        elif 'You are crazy.' in query:
            speak("Whaat!? I feel perfectly sane.")
        elif 'who is the director of soryavanshi' in query:
            speak("Rohit Shetty is the director of the movie soryavanshi")
        elif 'You are an idiot' in query:
            speak("I am trying my best.")
        elif 'What you did last night' in query:
            speak("I was trying new cooking recipies")
        elif 'what is your hobby' in query:
            speak("My hobbys are Coding, Programming, Sports and Household Work.")
        elif 'where do you live' in query:
            speak("I live in India")
        elif 'what is your age' in query:
            speak("I am a virtual assistant, I do not have age!")
        elif 'what is my name' in query:
            speak("I don't know your name. Tell me your name so I can save it to my system.")
        elif 'what is your name' in query:
            speak("My name is Jarvis. I am your friendly desktop assistant")
        elif 'which is your favorite animal' in query:
            speak("My favorite animals are Dogs and Cats")
        elif 'who is the prime minister of india' in query:
            speak("Shri Narendra Modi is the prime minister of India.")
        elif 'who is the president of america' in query:
            speak("Joe Biden is President of America.")
        elif 'good morning' in query:
            speak("Good Morning!")
        elif 'who inveted bulb' in query:
            speak("Thomas Elva Edison invented the Bulb")
        elif 'good afternoon' in query:
            speak("Good Afternoon!")
        elif 'good evening' in query:
            speak("Good Evening!")
        elif 'play jai jai shiv shankar' in query:
            speak("Playing Jai Jai Shiv Shankar Song...")
            print("Playing Jai Jai Shiv Shankar Song...")
            webbrowser.open("https://music.youtube.com/watch?v=IDSMj9wM9Os&feature=share")
        elif 'play free fire cobra theme' in query:
            speak("Playing Garena Free Fire The Cobra Theme...")
            print("Playing Garena Free Fire The Cobra Theme...")
            webbrowser.open("https://music.youtube.com/watch?v=ldV1-HjXM0g&feature=share")
        elif 'latest feature of microsoft windows' in query:
            speak("The latest feature of Microsoft Windows is Windows Ten.")
            print("The latest feature of Microsoft Windows is Windows Ten.")
        elif 'open gmail' in query:
            speak("Opening Gmail...")
            print("Opening Gmail...")
            webbrowser.open("https://mail.google.com/mail/u/0/#inbox")
        elif 'how am i looking today' in query:
            speak("As good as always!")
            print("As good as always!")
        elif 'open google drive' in query:
            webbrowser.open("https://drive.google.com/drive/u/0/my-drive")
        elif 'open translator' in query:
            webbrowser.open("https://translate.google.com/")
        elif 'open google maps' in query:
            webbrowser.open("https://www.google.com/maps")
        elif 'open news' in query:
            webbrowser.open("https://news.google.com/")
        elif "what's in today's news" in query:
            webbrowser.open("https://news.google.com/")
        elif ""